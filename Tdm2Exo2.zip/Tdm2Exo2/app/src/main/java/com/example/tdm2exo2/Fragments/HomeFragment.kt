package com.example.tdm2exo2.Fragments

import android.app.DatePickerDialog
import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import androidx.room.Room
import com.example.tdm2exo2.InterventionAdapter
import com.example.tdm2exo2.database.DataBase
import com.example.tdm2exo2.model.Intervention
import java.util.*






class HomeFragment : Fragment(), DatePickerDialog.OnDateSetListener {


    companion object {
        var interventions:ArrayList<Intervention> = ArrayList<Intervention>()
        val db = Room.databaseBuilder(
            ,
            DataBase::class.java, "intervention.db"
        ).build()
    }


    var fileName = ""

    lateinit var interventionAdapter : InterventionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GlobalScope.launch {
            db.interventionDao().insertAll(Intervention(12,Date().toString(),"jjdjjd","in")
                    interventions = db.interventionDao().getAll()

            data?.forEach {
                println(it)
            }
        }
       interventionAdapter = InterventionAdapter(interventions,context!!)

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var rootView = inflater!!.inflate(com.example.tdm2exo2.R.layout.fragment_home, container, false)
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list_interventions.adapter = interventionAdapter
        list_interventions.isTextFilterEnabled=true

        val datePickerDialog = DatePickerDialog(
            context, this,2018,1,1
        )

        search_btn.setOnClickListener {

            datePickerDialog.show();
        }
    }


    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {


        val calendar = Calendar.getInstance()

        calendar.set(year, month, dayOfMonth)


        val date=calendar.time.toString().removeRange(11,30)
        if (TextUtils.isEmpty(date)) {
            list_interventions.clearTextFilter();
        }
        else {
            list_interventions.setFilterText(date);
        }
    }
}


