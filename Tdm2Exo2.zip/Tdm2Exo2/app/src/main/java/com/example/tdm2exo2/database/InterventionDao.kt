package com.example.tdm2exo2.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.tdm2exo2.model.Intervention

@Dao
interface InterventionDao
{


        @Query("SELECT * FROM intervention")
        fun getAll(): ArrayList<Intervention>



        @Insert
        fun insertAll(vararg intervention: Intervention)

        @Delete
        fun delete(intervention: Intervention)


}